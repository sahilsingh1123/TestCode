# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

# Intro
This above example is to show how we would be using this .md file
for showing the user introduction in github repo or anywhere else.