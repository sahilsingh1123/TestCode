def printMessage():
    return print("message from inside the test_demo file")